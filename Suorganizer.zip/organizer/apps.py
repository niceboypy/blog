from django.apps import AppConfig


class OrganizerConfig(AppConfig):
    name = 'organizer'
