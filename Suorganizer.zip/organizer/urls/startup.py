from django.urls import re_path

from ..views import (
                    startup_detail,
                    StartupList,
                    StartupCreate,
                    StartupUpdate,
                    StartupDelete)

urlpatterns=[re_path(r'^$', 
            StartupList.as_view(),
            name='organizer_startup_list'),

    re_path(r'^create/$',
            StartupCreate.as_view(),
            name='organizer_startup_create'),
    
    re_path(r'^(?P<slug>[\w\-]+)/$',
            startup_detail,
            name='organizer_startup_detail'),
 
    re_path(r'^(?P<slug>[\w\-]+)/update/$',
            StartupUpdate.as_view(),
            name='organizer_startup_update'),

    re_path(r'^(?P<slug>[\w\-]+)/delete/$',
            StartupDelete.as_view(), 
            name='organizer_startup_delete'),]