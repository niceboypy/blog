from django.urls import re_path
from blog import urls as blog_urls
from .views import (PostCreate,PostList, post_detail,
                        PostUpdate, PostDelete)


urlpatterns=[
    re_path(r'^$', 
        PostList.as_view(),
        {'parent_template':'base.html'},
        name='blog_post_list'),

    re_path(r'^create/$',
            PostCreate.as_view(),
            name='blog_post_create'),

    re_path(r'(?P<year>\d{4})/(?P<month>\d{1,2})/(?P<slug>[\w\-]+)/$',
            post_detail,
            name='blog_post_detail'),

    re_path(r'(?P<year>\d{4})/(?P<month>\d{1,2})/(?P<slug>[\w\-]+)/update/$',
            PostUpdate.as_view(),
            name='blog_post_update'),

    re_path(r'(?P<year>\d{4})/(?P<month>\d{1,2})/(?P<slug>[\w\-]+)/delete/$',
            PostDelete.as_view(),
            name='blog_post_delete')
]